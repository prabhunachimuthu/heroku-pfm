﻿

namespace SofttrendsAddon.ViewModels
{
    public class AppOrganization
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}
