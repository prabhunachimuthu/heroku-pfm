﻿

namespace SofttrendsAddon.ViewModels
{
    public class SSOData
    {
        public string id { get; set; }
        public string token { get; set; }
        public string timestamp { get; set; }
        public string app { get; set; }
        public string email { get; set; }
    }
}
